// import the library
// import { library } from '@fortawesome/fontawesome-svg-core';

// import { Howl, Howler } from 'howler';

import { RichText } from '@wordpress/block-editor';

// import your icons
// import {
// 	faCode,
// 	faHighlighter,
// 	faBackward,
// 	faPlay,
// 	faPause,
//	faForward,
// } from '@fortawesome/free-solid-svg-icons';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

//library.add( faCode, faHighlighter, faBackward, faPlay, faPause, faForward);

export default function ss_player( attributes ) {
	console.log( 'CHECK Attributes: ',attributes );
	return null;
}
