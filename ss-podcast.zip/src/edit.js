import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import {
	SelectControl,
	PanelBody,
	Button,
	Placeholder,
	TextControl,
} from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';

import './editor.scss';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/developers/block-api/block-edit-save/#edit
 *
 * @return {WPElement} Element to render.
 */
export default function Edit( { attributes, setAttributes } ) {
	const blockProps = useBlockProps();

	const onSubmitURL = ( event ) => {
		event.preventDefault();
		const { podcastURL } = attributes;
		// console.log(podcastURL);

		apiFetch( {
			path: '/ss-podcast/v1/getxml/' + btoa( podcastURL ),
			method: 'POST',
			data: { url: btoa( podcastURL ) },
		} )
			.then( ( resp ) => {
				// console.log(resp);
				// console.log(resp["items"]);
				setAttributes( { podcastEpisodes: resp[ 'items' ] } );
			} )
			.catch( ( error ) => {
				console.log( error );
			} );
	};

	const onFetchChange = ( value ) => {
		// console.log("Dropdown Changed", value);
		setAttributes( { episodesSelected: value } );
	};

	return (
		<div { ...blockProps }>
			<Placeholder>
				<form onSubmit={ onSubmitURL }>
					<TextControl
						placeholder={ __( 'Enter URL here…', 'ss-podcast' ) }
						value={ attributes.podcastURL }
						onChange={ ( value ) =>
							setAttributes( { podcastURL: value } )
						}
						className={ 'components-placeholder__input' }
					/>
					<Button isLarge type="submit">
						{ __( 'Use URL', 'ss-podcast' ) }
					</Button>
				</form>
			</Placeholder>
			<InspectorControls>
				<PanelBody
					initialOpen={ true }
					title={ __( 'Fetched Episodes', 'ss-podcast' ) }
				>
					<SelectControl
						label={ __( 'Fetched Podcast Episodes', 'ss-podcast' ) }
						value={ attributes.episodesSelected }
						onChange={ onFetchChange }
						options={ attributes.podcastEpisodes }
					/>
				</PanelBody>
			</InspectorControls>
		</div>
	);
}
